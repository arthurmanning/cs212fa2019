/**
 * Author: Arthur T. Manning
 * Email: amanning@emmaus.edu
 * Date: Nov 22, 2019
 */
/**
 * @author atmanning
 *
 */
module manningBibleStats {
	requires java.desktop;
}