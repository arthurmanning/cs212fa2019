/**
 * Author: Arthur T. Manning
 * Email: amanning@emmaus.edu
 * Date: Nov 22, 2019
 */
package manningBibleStats;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

/**
 * @author atmanning
 *
 */
public class MainJFrame extends JFrame {

	private JPanel contentPane;
	JTextArea textAreaStats;
	
	ArrayList<Book> aBible = new ArrayList<>();
	ArrayList<String> alWords = new ArrayList<>();
	ArrayList<Integer> alWordCount = new ArrayList<>();
	ArrayList<WordStat> alWordStats = new ArrayList<>();
	Map<String,Integer> wStats = new HashMap<String,Integer>();
	private JTextField textFieldBook;
	private JTextField textFieldChapter;
	private JTextField textFieldVerse;
	private JTextField textFieldWord;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainJFrame frame = new MainJFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainJFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 649, 490);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(24, 11, 584, 415);
		contentPane.add(tabbedPane);
		
		JPanel panelVerse = new JPanel();
		tabbedPane.addTab("Bible View", null, panelVerse, null);
		panelVerse.setLayout(null);
		
		JLabel lblFirstPanel = new JLabel("Use this page to view verses of the Bible.");
		lblFirstPanel.setBounds(45, 11, 324, 34);
		panelVerse.add(lblFirstPanel);
		
		JButton btnLoadBible = new JButton("Load Bible");
		btnLoadBible.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				loadBible();
			}
		});
		btnLoadBible.setBounds(33, 285, 254, 23);
		panelVerse.add(btnLoadBible);
		
		textFieldBook = new JTextField();
		textFieldBook.setToolTipText("Book");
		textFieldBook.setBounds(45, 56, 96, 20);
		panelVerse.add(textFieldBook);
		textFieldBook.setColumns(10);
		
		textFieldChapter = new JTextField();
		textFieldChapter.setBounds(167, 56, 96, 20);
		panelVerse.add(textFieldChapter);
		textFieldChapter.setColumns(10);
		
		textFieldVerse = new JTextField();
		textFieldVerse.setBounds(289, 56, 96, 20);
		panelVerse.add(textFieldVerse);
		textFieldVerse.setColumns(10);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(45, 84, 450, 67);
		panelVerse.add(textArea);
		
		JButton btnShowIt = new JButton("Show it!");
		btnShowIt.setBounds(406, 55, 89, 23);
		panelVerse.add(btnShowIt);
		
		JLabel lblBook = new JLabel("Book");
		lblBook.setBounds(45, 41, 48, 14);
		panelVerse.add(lblBook);
		
		JLabel lblChapter = new JLabel("Chapter");
		lblChapter.setBounds(167, 41, 48, 14);
		panelVerse.add(lblChapter);
		
		JLabel lblVerse = new JLabel("Verse");
		lblVerse.setBounds(289, 41, 48, 14);
		panelVerse.add(lblVerse);
		
		JPanel panelStats = new JPanel();
		tabbedPane.addTab("Stats", null, panelStats, null);
		panelStats.setLayout(null);
		
		JLabel lblSecondPanel = new JLabel("stats panel");
		lblSecondPanel.setBounds(26, 11, 112, 14);
		panelStats.add(lblSecondPanel);
		
		JButton btnAlphabetical = new JButton("Alphabetical");
		btnAlphabetical.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// gather stats for all the books
				for( Book b : aBible ) {
					b.wordStats(wStats);  // wStats available for stats display
					b.wordStats(alWords, alWordCount);
					b.wordStats(alWordStats);
				}
				
				// now display them
				// display first 100 words
				int n=0;
				
				ArrayList<String> alWords = new ArrayList<>(wStats.keySet());
				ArrayList<String> alWordsAndCount = new ArrayList<>();
				for( WordStat ws : alWordStats )
					alWordsAndCount.add(ws.toString());
				Collections.sort(alWordsAndCount);
				Collections.sort(alWords);
				
				while( n++ < 100 ) {
					String key = alWords.get(n);
					textAreaStats.append(key + ": " + wStats.get(key) 
					+ " - \t" + alWordsAndCount.get(n) + " \n");
				}
			}
		});
		btnAlphabetical.setBounds(91, 7, 112, 23);
		panelStats.add(btnAlphabetical);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(26, 45, 525, 314);
		panelStats.add(scrollPane);
		
		textAreaStats = new JTextArea();
		scrollPane.setViewportView(textAreaStats);
		
		JButton btnSortByNumber = new JButton("Sorted by #Occurrences");
		btnSortByNumber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSortByNumber.setBounds(219, 11, 178, 19);
		panelStats.add(btnSortByNumber);
		
		JPanel panelWordLookup = new JPanel();
		tabbedPane.addTab("Word Locations", null, panelWordLookup, null);
		panelWordLookup.setLayout(null);
		
		JLabel lblWordLocations = new JLabel("Word locations - Enter a word and I will show all it's locations");
		lblWordLocations.setBounds(10, 11, 559, 14);
		panelWordLookup.add(lblWordLocations);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(20, 68, 531, 224);
		panelWordLookup.add(scrollPane_1);
		
		JTextArea textArea_1 = new JTextArea();
		scrollPane_1.setViewportView(textArea_1);
		
		textFieldWord = new JTextField();
		textFieldWord.setBounds(20, 37, 127, 20);
		panelWordLookup.add(textFieldWord);
		textFieldWord.setColumns(10);
		
		JButton btnSearch = new JButton("Search!");
		btnSearch.setBounds(157, 34, 89, 23);
		panelWordLookup.add(btnSearch);
	}
	
	void loadBible() {
		try {
			Scanner bibleScanner = new Scanner( new File("kjvdat.txt"));
			// read first 100 lines
			int n=100;
			ArrayList<Verse> aV = new ArrayList<>();

			
			String sLine;
			String sBookCurrent="";
			Book bCurrent = null;
			while( bibleScanner.hasNext()) {  
				sLine = bibleScanner.nextLine();
				int iDelimiter = sLine.indexOf('|');
				String sBook = sLine.substring(0,iDelimiter);
				if(!sBook.equals(sBookCurrent)) {
					sBookCurrent = sBook;
					bCurrent = new Book(sBookCurrent);
					aBible.add(bCurrent);
				}
				bCurrent.verseAdd(sLine.substring(iDelimiter+1));
				//aV.add(new Verse(bibleScanner.nextLine()));
			}
			
			System.out.println("Bible loaded: books total=" + aBible.size());
			// get chapter count
			int cCount = 0;
			// get word count
			int wCount=0;

			for( Book b : aBible) {
				cCount += b.getChapterCount();
				wCount += b.getWordCount();

			}
			System.out.println("  Chapter count=" + cCount + ", Word Count=" + wCount);
			

			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
